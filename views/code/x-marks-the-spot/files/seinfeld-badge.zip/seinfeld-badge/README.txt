A jQuery badge for http://calendaraboutnothing.com/ using YQL

To add to any page:
* include the seinfeld-badge.js file
* include the seinfeld-badge.css file
* include an HTML element with a class of 'seinfeld-badge' and another class for the user whose account you want: 'user-lachlanhardy'

It was built to look good at approximately 300px, but isn't constrained to width. If you drop it into a parent element with a different width you may have to makes minor changes to CSS, but it's pretty flexible.
