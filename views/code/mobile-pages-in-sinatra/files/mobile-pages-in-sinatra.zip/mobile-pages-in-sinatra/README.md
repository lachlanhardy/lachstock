# Run
From the commandline (on OSX):

    $ sudo gem install sinatra haml
    $ ruby mobile.rb

Then go to [http://localhost:4567](http://localhost:4567) in your browser.


# Copyright

Copyright (c) 2010 Lachlan Hardy. See LICENSE for details.
